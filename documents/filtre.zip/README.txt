A Pen created at CodePen.io. You can find this one at https://codepen.io/AurelieT/pen/JGxMgo.

 Example of Bootstrap Table, with search,  a column filter, data checkbox, an export