A Pen created at CodePen.io. You can find this one at https://codepen.io/Hoebink/pen/LGyyWK.

 Fun nav toggle with some animation