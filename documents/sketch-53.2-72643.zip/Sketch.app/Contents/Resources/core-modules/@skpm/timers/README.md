# `timers` for Sketch

All the [NodeJS timers](https://nodejs.org/api/timers.html) API is available.
