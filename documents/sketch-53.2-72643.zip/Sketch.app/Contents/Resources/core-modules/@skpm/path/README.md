# `path` for Sketch

All the [nodejs path](https://nodejs.org/api/path.html) API is available.

A additional method is available:

- `path.resourcePath(string)`: which returns the path to a resource in the plugin bundle or `undefined` if it doesn't exist.
