/* 

Support: IE10+, FF28+

Checkbox hack:
http://timpietrusky.com/advanced-checkbox-hack 

Polyfill for old IE:
http://flexiejs.com/

Warning: Not super accessible - just for fun


*/