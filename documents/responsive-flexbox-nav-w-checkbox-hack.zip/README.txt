A Pen created at CodePen.io. You can find this one at https://codepen.io/joe-watkins/pen/Emzxf.

 A responsive navigation with dropdowns that leverages CSS Flexbox and Tim Pietrusky's checkbox :checked hack to show hide nav on smaller screens - no JS

*poses accessibility concerns and is just a demo