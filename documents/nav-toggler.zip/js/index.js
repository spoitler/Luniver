$(".navToggle").click (function(){
  $(this).toggleClass("open");
  $("nav").toggleClass("open");
});